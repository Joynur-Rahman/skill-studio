# SkillStudio model package

Files
- `skillstudio_model.pt`  weights + vocabulary + job bank + readiness calibration + settings (data only, no code)
- `skillstudio_nn.py`     the model code; REQUIRED to load the .pt (keep both files in the same folder / on the Python path)
- `sample_student.json`   example input;  `sample_output.json`  example of what `analyze()` returns
- `metrics.json`, `config.json`, `requirements.txt`

Quick start
```python
import json
from skillstudio_nn import SkillStudioPredictor

pred = SkillStudioPredictor.load("skillstudio_model.pt", device="cpu")     # load once at app start-up
student = json.load(open("sample_student.json"))                            # your app builds this dict
result = pred.analyze(student, top_n=10)                                    # readiness + recommendations + skill_roi

pred.match_jobs(student, ["JOB00001", "JOB00002"])                          # match against specific jobs
# pred.readiness_table(students_df)                                         # batch readiness for many students
# pred.set_job_bank(new_jobs_df)                                            # swap in new job postings, no retraining
```

Input: a dict with the students.csv fields below. Multi-value fields are pipe-separated strings ("Python|SQL").
Missing or null fields are allowed; unknown skills are ignored and returned in `unrecognized_skills`.
degree, specialization, graduation_year, technical_skills, programming_languages, skill_proficiency ("Python:Advanced|SQL:Beginner"),
projects_count, project_technologies, certifications, internship_months, work_experience_months,
preferred_roles, preferred_locations, preferred_work_mode, job_type_preference.

Output (JSON-serialisable): `readiness` (score, percentile, band, components, role_readiness, advice), `recommendations` (list: match_score, fit_label,
probabilities, offer_likelihood, matched/related/missing skills, job details), `skill_roi`, `unrecognized_skills`.

Notes
- Load the .pt only through `SkillStudioPredictor.load` (it uses `torch.load(..., weights_only=True)`; no pickled code is executed).
- Match scores are only meaningful for the job types seen in training; near-zero scores mean "not a fit".
- After retraining, replace BOTH files together.
